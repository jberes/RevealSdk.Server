﻿using DocumentFormat.OpenXml.Office.CoverPageProps;
using Infragistics.ReportPlus.DashboardModel;
using Reveal.Sdk;


namespace RevealSdk.Server
{
    internal class DataSourceProvider : IRVDataSourceProvider
    {
        public Task<RVDataSourceItem> ChangeDataSourceItemAsync(
            IRVUserContext userContext,
            string dashboardId,
            RVDataSourceItem dataSourceItem)
         {

            if (dataSourceItem is RVSqlServerDataSourceItem excelDsi)
            {
                //var sqlDs = new RVSqlServerDataSource()
                //{
                //    Id = "s0106linuxsql1.infragistics.local",
                //    Host = "s0106linuxsql1.infragistics.local",
                //    Port = 1433,
                //    Database = "devtest"
                //};

                //var sqlDsi = new RVSqlServerDataSourceItem(sqlDs)
                //{
                //    Id = excelDsi.Sheet,
                //    Table = excelDsi.Sheet
                //};
                //return Task.FromResult<RVDataSourceItem>(sqlDsi);
            }

            else if (dataSourceItem is RVPostgresDataSourceItem pgDsi)
            {      
                var userContextId = (IRVUserContext)userContext;
                pgDsi.Title = "Server Title";
                pgDsi.Database = "NorthwindPostgres";
                pgDsi.CustomQuery = $"SELECT * FROM {pgDsi.Table} " +
                    $"WHERE customer_id = '{userContextId.UserId}'";

                //if (sqlServerDsi.Table == "Customers")
                //{
                //sqlServerDsi.Table = "Employees";

                //sqlServerDsi.Table = null;
                //}
            }


            else if (dataSourceItem is RVRESTDataSourceItem restDsi)
            {
                var userContextId = (IRVUserContext)userContext;
                restDsi.Title = "My Title";
                restDsi.Subtitle = "My Sub Title";
                restDsi.Url = $"https://northwindcloud.azurewebsites.net/api/customer_orders/{userContextId.UserId}";                
            }


            else if (dataSourceItem is RVBigQueryDataSourceItem bgDsi)
            {
                bgDsi.Id = "MyBigQueryItem";
                bgDsi.ProjectId = "bigquery-public-data";
                bgDsi.DatasetId = "chicago_crime";
                bgDsi.Table = "crime";
                bgDsi.CustomQuery = "SELECT * FROM bigquery-public-data.chicago_crime.crime where primary_type = 'HOMICIDE' LIMIT 1000";
            }

            else if (dataSourceItem is RVSnowflakeDataSourceItem snowflakeDsi)
            {

                Console.Write("I am here");
                //snowflakeDsi.DataSource
                //snowflakeDsi.Database = "SNOWFLAKE_SAMPLE_DATA";
                //snowflakeDsi.Table = "CALL_CENTER";

            }
            
            return Task.FromResult((RVDataSourceItem)dataSourceItem);
        }

        public Task<RVDashboardDataSource> ChangeDataSourceAsync(IRVUserContext userContext, RVDashboardDataSource dataSource)
        {
            if (dataSource is RVSnowflakeDataSource sfDs)
            {
                sfDs.Id = "snowflakeDSId";
                sfDs.Title = "Snowflake DS";
                sfDs.Account = "al16914";
                sfDs.Host = "gpiskyj-al16914.snowflakecomputing.com";
                sfDs.Database = "SNOWFLAKE_SAMPLE_DATA";
            }

            if (dataSource is RVRESTDataSource rstDs)
            {

                rstDs.Id = "RestDataSource";
                rstDs.Title = "Northwind";
                rstDs.Subtitle = "Orders";
                rstDs.Url = "https://northwindcloud.azurewebsites.net/api/orders_qry";
                rstDs.UseAnonymousAuthentication = true;
            }


            return Task.FromResult(dataSource);
        }
    }
}